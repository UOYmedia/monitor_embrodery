#!/usr/bin/env python3
# Broker MQTT tối giản (3.1/3.1.1) + bắt tay auth XXTEA cho máy Dahao BECS-A15.
# Mục tiêu: qua được auth/login -> secret -> encode -> confirm để máy publish `state`.
import socket, threading, struct, json, base64, os, sys, time, random
from Crypto.Cipher import AES

HOST='0.0.0.0'; PORT=3865
KEY=b'***REMOVED***'; IV=b'***REMOVED***'
A=[0x40269286,0x7c032a72,0x6a6de9ac,0x5c258294]
B=[0x650a9c4f,0x4ef3306a,0x32c03b32,0x59770a4a]
LOG=os.path.join(os.path.dirname(__file__),'broker.log')
STATE=os.path.join(os.path.dirname(__file__),'state.log')
lock=threading.Lock()
clients=[]  # danh sách (sock, subs set)

def log(*a):
    line=' '.join(str(x) for x in a)
    with lock:
        with open(LOG,'a') as f: f.write(line+'\n')
    print(line, flush=True)

def xxtea_encrypt(v, key):
    v=list(v); n=len(v); DELTA=0x9E3779B9; m=0xFFFFFFFF
    q=6+52//n; s=0; z=v[n-1]
    for _ in range(q):
        s=(s+DELTA)&m; e=(s>>2)&3
        for p in range(n):
            y=v[(p+1)%n]
            mx=((((z>>5)^((y<<2)&m))+(((y>>3))^((z<<4)&m)))&m) ^ (((s^y)+(key[(p&3)^e]^z))&m)
            v[p]=(v[p]+mx)&m; z=v[p]
    return v

def s32(x):  # uint32 -> int32 (JSON của jsoncpp dùng int có dấu)
    return x-0x100000000 if x>=0x80000000 else x
def u32(x):
    return x & 0xFFFFFFFF

def aes_dec(b64):
    raw=base64.b64decode(b64)
    return AES.new(KEY,AES.MODE_CBC,IV).decrypt(raw)
def dec_json(payload):
    pt=aes_dec(payload)
    if pt:
        pad=pt[-1]
        if 1<=pad<=16 and pt[-pad:]==bytes([pad])*pad:  # bỏ đệm PKCS7 đúng chuẩn
            pt=pt[:-pad]
    return json.loads(pt.decode('utf-8','ignore').strip())
def aes_enc_json(obj):
    js=json.dumps(obj)  # nội dung JSON compact
    data=js.encode()
    pad=16-(len(data)%16)          # PKCS7 (máy dùng: login kết thúc }\x02\x02)
    data=data+bytes([pad])*pad
    ct=AES.new(KEY,AES.MODE_CBC,IV).encrypt(data)
    return base64.b64encode(ct).decode()

# ---- MQTT framing ----
def read_exact(sock,n):
    buf=b''
    while len(buf)<n:
        c=sock.recv(n-len(buf))
        if not c: return None
        buf+=c
    return buf
def read_remlen(sock):
    mult=1; val=0
    while True:
        b=read_exact(sock,1)
        if b is None: return None
        b=b[0]; val+=(b&0x7f)*mult
        if not (b&0x80): break
        mult*=128
    return val
def enc_remlen(n):
    out=b''
    while True:
        d=n%128; n//=128
        if n>0: d|=0x80
        out+=bytes([d])
        if n<=0: break
    return out
def rd_str(buf,i):
    l=struct.unpack_from('>H',buf,i)[0]; i+=2
    return buf[i:i+l], i+l

def mk_publish(topic, payload, qos=0):
    tb=topic.encode()
    vh=struct.pack('>H',len(tb))+tb
    if qos>0: vh+=struct.pack('>H',1)  # packet id
    body=vh+payload
    return bytes([0x30|(qos<<1)])+enc_remlen(len(body))+body

def deliver(topic, payload):
    # gửi tới mọi client có subscription khớp
    with lock:
        targets=[c for c in clients if any(sub_match(s,topic) for s in c[1])]
    pkt=mk_publish(topic,payload,0)
    for c in targets:
        try: c[0].sendall(pkt)
        except Exception as e: log('deliver err',e)
    return len(targets)

def sub_match(sub, topic):
    ss=sub.split('/'); ts=topic.split('/')
    for i,s in enumerate(ss):
        if s=='#': return True
        if i>=len(ts): return False
        if s=='+': continue
        if s!=ts[i]: return False
    return len(ss)==len(ts)

def prettytxt(pt):
    try: return pt.rstrip(b' \x00').decode('utf-8')
    except: return repr(pt)

def handle_auth_login(conn_sub, topic, payload):
    # payload = base64 (bytes). Giải mã, lấy Nc, dựng auth/secret.
    try:
        js=dec_json(payload)
    except Exception as e:
        log('  login decrypt/parse lỗi:', e, 'raw=', prettytxt(payload)[:80]); return
    dev=topic.split('/')[-1]
    body=js.get('body',{}); hdr=js.get('header',{})
    Nc=[u32(int(x)) for x in body.get('secret',[0,0,0,0])][:4]
    while len(Nc)<4: Nc.append(Nc[-1] if Nc else 0)
    # SERVER THẬT (đã dịch ngược): secret = 4 giá trị GIỐNG NHAU trong [1e8, 1e8+32767]
    nsv=random.randint(10**8, 10**8+32767)
    Ns=[nsv,nsv,nsv,nsv]
    encode=[u32(x) for x in xxtea_encrypt(A, Nc)]     # body.encode = XXTEA(A, Nc)
    expect=[u32(x) for x in xxtea_encrypt(B, Ns)]     # mã client kỳ vọng = XXTEA(B, Ns)
    with lock:
        s=SESS.setdefault(dev,{'expects':[]})
        s['Ns']=Ns; s['Nc']=Nc; s['expect']=expect
        s['expects'].append(expect)
        s['expects']=s['expects'][-60:]   # giữ 60 giá trị kỳ vọng gần nhất
    # secret & encode PHẢI là REAL(double) đúng như jsoncpp fildl (signed int32 -> double)
    reply={"header":{"mesgNo":str(hdr.get('mesgNo',"1")),"version":"1.0"},
           "body":{"secret":[float(s32(x)) for x in Ns],
                   "encode":[float(s32(x)) for x in encode]}}
    ct=aes_enc_json(reply)
    rtopic='emCAD/server/v1/auth/secret/'+dev
    n=deliver(rtopic, ct.encode())
    log('  << login mesgNo=%s Nc=%d | >> secret Ns=%d encode=%s expect=%s (sub=%d)'%(hdr.get('mesgNo'),Nc[0],nsv,encode,expect,n))

def handle_auth_encode(topic, payload):
    try:
        js=dec_json(payload)
    except Exception as e:
        log('  encode parse lỗi:',e); return
    dev=topic.split('/')[-1]
    enc=[u32(int(x)) for x in js.get('body',{}).get('encode',[])][:4]
    sess=SESS.get(dev) or {}
    expects=sess.get('expects') or ([sess['expect']] if sess.get('expect') else [])
    match = enc in expects
    log('  ################ MÁY GỬI auth/encode! enc=%s  (khớp 1 trong %d expect gần đây=%s)'%(enc,len(expects),match))
    hdr=js.get('header',{})
    if match:
        # SERVER THẬT: auth/confirm body chỉ có ackMesg = 0 (real). KHÔNG iResult, KHÔNG reason.
        confirm={"header":{"mesgNo":str(hdr.get('mesgNo',"1")),"version":"1.0"},
                 "body":{"ackMesg":0.0}}
        ct=aes_enc_json(confirm)
        rtopic='emCAD/server/v1/auth/confirm/'+dev
        n=deliver(rtopic, ct.encode())
        log('  >> auth/confirm ackMesg=0 KHỚP -> gửi (giao tới %d sub) *** AUTH XONG ***'%n)

SESS={}
HYPO_I=[0]

# ---- Forward state đã giải mã -> cổng dial-in của bridge (JSON contract, newline-delimited) ----
FWD_HOST=os.environ.get('BRIDGE_HOST','127.0.0.1')
FWD_PORT=int(os.environ.get('BRIDGE_PORT','1600'))
FWD_ON=os.environ.get('FWD_ENABLE','1')!='0'
_fwd={'sock':None,'last_try':0.0}
_prev={}  # dev -> (patternName, curStitch): suy status từ việc curStitch có tăng không

def _iso():
    return time.strftime('%Y-%m-%dT%H:%M:%S',time.gmtime())+'Z'

def state_to_status(dev, body):
    # Enum `state` không mã hoá chuỗi trong exe; suy status TRUNG THỰC từ curStitch.
    st=body.get('state'); cur=body.get('curStitch'); pat=body.get('patternName')
    if st==-1: return 'unknown'          # sentinel mất dữ liệu
    prev=_prev.get(dev); _prev[dev]=(pat,cur)
    if prev and prev[0]==pat and isinstance(cur,int) and isinstance(prev[1],int):
        return 'running' if cur>prev[1] else 'stopped'
    return 'unknown'                      # lần đầu / vừa đổi mẫu: chưa đủ cơ sở

def build_frame(dev, body):
    # KHÔNG map curStitch->odometer: curStitch reset theo từng mẫu, không đơn điệu.
    return {'observedAt':_iso(),'status':state_to_status(dev,body),
            'job':{'fileName':body.get('patternName') or None,
                   'currentStitch':body.get('curStitch'),
                   'totalStitches':body.get('patternStitch')}}

def forward_to_bridge(dev, body):
    if not FWD_ON: return
    try:
        line=(json.dumps(build_frame(dev,body),separators=(',',':'))+'\n').encode()
        s=_fwd['sock']
        if s is None:
            now=time.time()
            if now-_fwd['last_try']<5: return  # backoff khi bridge chưa lên
            _fwd['last_try']=now
            s=socket.create_connection((FWD_HOST,FWD_PORT),timeout=2)
            _fwd['sock']=s; log('  [FWD] nối bridge %s:%d OK'%(FWD_HOST,FWD_PORT))
        s.sendall(line)
    except Exception as e:
        log('  [FWD] lỗi (%s) -> đóng socket'%e)
        try: _fwd['sock'].close()
        except: pass
        _fwd['sock']=None

def xxtea_decrypt(v, key):
    v=list(v); n=len(v); DELTA=0x9E3779B9; m=0xFFFFFFFF
    q=6+52//n; s=(q*DELTA)&m
    y=v[0]
    for _ in range(q):
        e=(s>>2)&3
        for p in range(n-1,-1,-1):
            z=v[(p-1)%n]
            mx=((((z>>5)^((y<<2)&m))+(((y>>3))^((z<<4)&m)))&m) ^ (((s^y)+(key[(p&3)^e]^z))&m)
            v[p]=(v[p]-mx)&m; y=v[p]
        s=(s-DELTA)&m
    return v

# Danh sách giả thuyết cho body.encode (proof server gửi để client xác thực).
# Trả (field_encode_values, field_secret_values_override_or_None, ten)
def hypo(idx, A, B, Nc4, Ns):
    Nc=Nc4[0]
    E=lambda v,k: [u32(x) for x in xxtea_encrypt([u32(t) for t in v],[u32(t) for t in k])]
    D=lambda v,k: [u32(x) for x in xxtea_decrypt([u32(t) for t in v],[u32(t) for t in k])]
    H=[
      ("enc(A,Nc)",       E(A,Nc4),      None),
      ("enc(Nc,A)",       E(Nc4,A),      None),
      ("dec(A,Nc)",       D(A,Nc4),      None),
      ("dec(Nc,A)",       D(Nc4,A),      None),
      ("enc(A,Ns)",       E(A,Ns),       None),
      ("enc(Ns,A)",       E(Ns,A),       None),
      ("enc(B,Nc)",       E(B,Nc4),      None),
      ("enc(Nc,B)",       E(Nc4,B),      None),
      ("enc(B,Ns)",       E(B,Ns),       None),   # server gửi luôn đáp án kỳ vọng
      ("enc(Ns,B)",       E(Ns,B),       None),
      ("secret=enc(A,Nc)",E(B,Ns),       E(A,Nc4)),  # proof ở field secret, encode=đáp án
      ("plainNs",         Ns,            None),      # encode = Ns (không transform)
      ("enc(A,Nc)_uns",   E(A,Nc4),      None),      # (đánh dấu để gửi unsigned)
    ]
    return H[idx % len(H)]



def client_thread(sock, addr):
    subs=set(); entry=[sock,subs]
    with lock: clients.append(entry)
    log('== KẾT NỐI TCP từ', addr)
    try:
        while True:
            hdr=read_exact(sock,1)
            if hdr is None: break
            typ=hdr[0]>>4; flags=hdr[0]&0xf
            rl=read_remlen(sock)
            if rl is None: break
            body=read_exact(sock,rl) if rl>0 else b''
            if body is None: break
            if typ==1:  # CONNECT
                pn,i=rd_str(body,0); level=body[i]; cflags=body[i+1]
                ka=struct.unpack_from('>H',body,i+2)[0]; i+=4
                cid,i=rd_str(body,i)
                log('CONNECT proto=%s lvl=%d cid=%s keepalive=%d cleanSession=%d cflags=0x%02x'%(pn.decode(errors='replace'),level,cid.decode(errors='replace'),ka,(cflags>>1)&1,cflags))
                sock.sendall(bytes([0x20,0x02,0x00,0x00]))  # CONNACK ok
            elif typ==3:  # PUBLISH
                qos=(flags>>1)&3
                topic,i=rd_str(body,0)
                pid=None
                if qos>0:
                    pid=struct.unpack_from('>H',body,i)[0]; i+=2
                payload=body[i:]
                t=topic.decode(errors='replace')
                if 'auth/login' in t:
                    log('  [PUB login] topic=%s qos=%d pid=%s dup=%d retain=%d'%(t,qos,pid,(flags>>3)&1,flags&1))
                    handle_auth_login(entry,t,payload)
                elif 'auth/encode' in t:
                    handle_auth_encode(t,payload)
                elif '/state' in t or 'state' in t.split('/'):
                    dev2=t.rsplit('/',1)[-1]
                    with open(STATE,'a') as f: f.write('%s %s\n'%(t,prettytxt(payload)))  # lưu base64 (script phân tích cũ vẫn giải mã được)
                    try:
                        b=dec_json(payload).get('body',{})
                        log('*** STATE dev=%s cur=%s tot=%s state=%s pat=%s'%(dev2,b.get('curStitch'),b.get('patternStitch'),b.get('state'),b.get('patternName')))
                        forward_to_bridge(dev2,b)
                    except Exception as e:
                        log('*** STATE parse lỗi: %s'%e)
                else:
                    log('PUBLISH %s  len=%d  %s'%(t,len(payload),prettytxt(payload)[:120]))
                if qos==1 and pid is not None:
                    sock.sendall(bytes([0x40,0x02])+struct.pack('>H',pid))  # PUBACK
                elif qos==2 and pid is not None:
                    sock.sendall(bytes([0x50,0x02])+struct.pack('>H',pid))  # PUBREC
            elif typ==6:  # PUBREL -> PUBCOMP (hoàn tất QoS2)
                pid=struct.unpack_from('>H',body,0)[0] if len(body)>=2 else 0
                sock.sendall(bytes([0x70,0x02])+struct.pack('>H',pid))  # PUBCOMP
            elif typ==8:  # SUBSCRIBE
                pid=struct.unpack_from('>H',body,0)[0]; i=2; rcodes=b''
                while i<len(body):
                    tp,i=rd_str(body,i); qos=body[i]; i+=1
                    subs.add(tp.decode(errors='replace')); rcodes+=bytes([qos])
                log('SUBSCRIBE', list(subs))
                sock.sendall(bytes([0x90])+enc_remlen(2+len(rcodes))+struct.pack('>H',pid)+rcodes)
            elif typ==12:  # PINGREQ
                sock.sendall(bytes([0xd0,0x00]))
            elif typ==14:  # DISCONNECT
                log('DISCONNECT', addr); break
            else:
                log('pkt type',typ,'rl',rl)
    except Exception as e:
        log('thread err',addr,e)
    finally:
        with lock:
            if entry in clients: clients.remove(entry)
        try: sock.close()
        except: pass
        log('== ĐÓNG', addr)

def main():
    open(LOG,'w').close()
    srv=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    srv.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
    srv.bind((HOST,PORT)); srv.listen(16)
    log('Broker lắng nghe %s:%d  (KEY/IV/A/B nạp sẵn, XXTEA)'%(HOST,PORT))
    while True:
        c,a=srv.accept()
        threading.Thread(target=client_thread,args=(c,a),daemon=True).start()

if __name__=='__main__':
    main()
